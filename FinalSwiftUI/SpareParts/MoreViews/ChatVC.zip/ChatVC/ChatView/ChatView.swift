//
//  ChatView.swift
//  FinalSwiftUI
//
//  Created by Mohab on 17/05/2025.
//

//import SwiftUI
//
//struct chatView: View {
//    @State private var newMessage: String = ""
//    @ObservedObject private var viewModel: ChatViewModel
//    init(viewModel: ChatViewModel) {
//        self._viewModel = ObservedObject(wrappedValue: viewModel)
//    }
//    var body: some View {
//        mainContetnt
//    }
//    
//    private var mainContetnt: some View {
//        VStack {
//            headerView
//            ShowViewState(state: viewModel.state) { Model in
//                listItem
//            }
//        }
//    }
//    
//    private var headerView: some View {
//        AppHeaderView(Title: "Messages".localized) {
//            viewModel.disMiss()
//        }
//    }
//    
//    private var listItem: some View {
//        List(viewModel.messages,id: \.id) { message in
//            mchanelCard(message: message)
//              
//        }
//    }
//    
//    private func mchanelCard(message: messageModel) -> some View {
//        HStack {
//            if message.is_mine == true {
//                Spacer()
//            }
//            
//            Text(message.message ?? "")
//                .padding()
//                .background(
//                    (message.is_mine ?? false)
//                    ? Color.blue
//                    : Color.gray.opacity(0.3)
//                )
//                .foregroundColor(
//                    (message.is_mine ?? false)
//                    ? .white
//                    : .black
//                )
//                .cornerRadius(12)
//            
//            if !(message.is_mine ?? false) {
//                Spacer()
//            }
//            
//            // Input Field
//            HStack {
//                TextField("Type message...", text: $newMessage)
//                    .textFieldStyle(RoundedBorderTextFieldStyle())
//                
//                Button("Send") {
//                    sendMessage()
//                }
//            }
//            .padding()
//        }
//        .navigationBarTitleDisplayMode(.inline)
//
//    }
//    
//    private func sendMessage() {
//        guard !newMessage.isEmpty else { return }
//
//        viewModel.sendMessage(paramter: .init(message:newMessage))
//        newMessage = ""
//    }
//}
//
