//
//  ChatViewModel.swift
//  MyAuctions
//
//  Created by مهاب موافي on 7/5/25.
//

import Foundation
import Foundation
import Combine
import SwiftUI


class ChatViewModel: ObservableObject {
    @Published var messages: [messageModel] = []
    @Published var state: viewState<[messageModel]?> = .idle
    @ObservedObject var coordinator: MainCoordinator
    var roomId: String
    private var currentPage = 1
    private var canLoadMore = true
    init(coordinator: MainCoordinator,roomId: String) {
        _coordinator = ObservedObject(wrappedValue: coordinator)
        self.roomId = roomId
        getChats()
    }
    
    func disMiss(){
        coordinator.path.removeLast()
    }
    
    
    
    func loadMoreIfNeeded(currentMessage: messageModel) {
        guard let last = messages.last else { return }
        
        if (currentMessage.id == last.id) && canLoadMore {
            getChats()
        }
    }
    
    func getChats(urlEndPoint:EndPoints = .chats, methodType: HTTPMethodType = .get) {
        let url = "\(hostName)\(urlEndPoint.rawValue)/\(roomId)/messages?page=\(currentPage)"
        state = .loading(loading: .progress)
        APIClient.shared.performRequestWithAlamofire(urlString: url, method: methodType, parameters:nil) { [weak self] (Model: BaseModelPaginate<[messageModel]>? , err : String? )in
            guard let self = self else { return }
            if Model?.status == "success" {
                messages.append(contentsOf: (Model?.data?.data ?? []).reversed())
                state = .loaded(data: Model?.data?.data ?? [])
                if self.currentPage < (Model?.data?.pagination?.lastPage ?? 0) {
                    self.currentPage = self.currentPage
                }else {
                    canLoadMore = false
                }
                
            }else {
                state = .error(err ?? "")
            }
        }
    }
    
    func sendMessage(urlEndPoint:EndPoints = .chats, methodType: HTTPMethodType = .post,paramter: BaseParameters) {
        let url = "\(hostName)\(urlEndPoint.rawValue)/\(roomId)/send"
        state = .loading(loading: .progress)
        APIClient.shared.performRequestWithAlamofire(urlString: url, method: methodType, parameters:paramter.toDictionary()) { [weak self] (Model: BaseModel<messageModel>? , err : String? )in
            guard let self = self else { return }
            if Model?.status == "success" {
                if let message = Model?.data {
                    messages.append(message)
                }
                
                state = .loaded(data: messages)
            }else {
                state = .error(err ?? "")
            }
        }
    }
}
