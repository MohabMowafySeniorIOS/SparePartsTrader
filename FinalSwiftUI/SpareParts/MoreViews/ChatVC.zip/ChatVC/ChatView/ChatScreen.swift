//
//  ChatScreen.swift
//  SpareParts
//
//  Created by Mohab on 13/02/2026.
//

import Foundation
import SwiftUI

import SwiftUI

struct chatView: View {
    
    @State private var messageText: String = ""
    @ObservedObject private var viewModel: ChatViewModel
    
    init(viewModel: ChatViewModel) {
        self._viewModel = ObservedObject(wrappedValue: viewModel)
    }
    
    var body: some View {
        VStack {
            headerView
            VStack(spacing: 0) {
                  scrollView
                  inputBar
              }
        }.background(Color(.systemGroupedBackground))
    }
}
private extension chatView {
    
    var headerView: some View {
        AppHeaderView(Title: "Messages".localized) {
            viewModel.disMiss()
        }
    }
}
private extension chatView {
    
    var scrollView: some View {
        ScrollViewReader { proxy in
            ScrollView {
                LazyVStack(spacing: 20) {
                    ForEach(viewModel.messages, id: \.id) { message in
                        MessageRow(message: message)
                            .id(message.id)
                            .onAppear {
                                viewModel.loadMoreIfNeeded(currentMessage: message)
                            }
                    }
                }
                .padding()
                .padding(.bottom, 70) // مساحة للـ input
            }
            .onAppear {
                scrollToBottom(proxy: proxy)
            }
            .onChange(of: viewModel.messages.count) { _ in
                scrollToBottom(proxy: proxy)
            }
            .onReceive(NotificationCenter.default.publisher(
                for: UIResponder.keyboardWillShowNotification)) { _ in
                scrollToBottom(proxy: proxy)
            }

            .onReceive(NotificationCenter.default.publisher(
                for: UIResponder.keyboardWillHideNotification)) { _ in
                    scrollToBottom(proxy: proxy)
            }
        }
    }
    
    func scrollToBottom(proxy: ScrollViewProxy) {
        guard let lastID = viewModel.messages.last?.id else { return }
        DispatchQueue.main.async {
            withAnimation(.easeOut(duration: 0.25)) {
                proxy.scrollTo(lastID, anchor: .bottom)
            }
        }
    }
}
private extension chatView {
    
    var inputBar: some View {
        HStack {
            
            Button {
                send()
            } label: {
                Image(systemName: "paperplane.fill")
                    .foregroundColor(.white)
                    .padding(10)
                    .background(Color.MainColor)
                    .clipShape(Circle())
            }
            
            TextField("Write Here".localized, text: $messageText)
                .multilineTextAlignment(.trailing)
                .padding(.horizontal, 16)
                .frame(height: 44)
                .background(Color(.secondarySystemBackground))
                .cornerRadius(22)
        }
        .padding(.horizontal)
        .padding(.vertical, 8)
        .background(.ultraThinMaterial)
    }
    
    func send() {
        let trimmed = messageText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        viewModel.sendMessage(paramter: .init(message: trimmed))
        messageText = ""
    }
}
struct MessageRow: View {
    
    let message: messageModel
    
    var body: some View {
        HStack(alignment: .bottom, spacing: 8) {
            
            if message.is_mine == true { Spacer() }
            
            if message.is_mine != true {
                RemoteImageView(imageUrl: message.sender?.avatar ?? "")
                    .frame(width: 32, height: 32)
                    .clipShape(Circle())
            }
            
            VStack(alignment: message.is_mine == true ? .trailing : .leading, spacing: 6) {
                
                if message.is_mine != true {
                    Text(message.sender?.name ?? "")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                
                Text(message.message ?? "")
                    .padding(12)
                    .background(
                        message.is_mine == true
                        ? Color.MainColor
                        : Color(.secondarySystemBackground)
                    )
                    .foregroundColor(message.is_mine == true ? .white : .primary)
                    .cornerRadius(18)
                
                Text("\(message.created_date ?? "") \(message.created_at ?? "")")
                    .font(.caption2)
                    .foregroundColor(.secondary)
            }
            
            if message.is_mine == true {
                RemoteImageView(imageUrl: message.sender?.avatar ?? "")
                    .frame(width: 32, height: 32)
                    .clipShape(Circle())
            }
            
            if message.is_mine != true { Spacer() }
        }
    }
}
