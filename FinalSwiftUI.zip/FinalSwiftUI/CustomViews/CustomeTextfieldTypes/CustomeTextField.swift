//
//  CustomeTextField.swift
//  FinalSwiftUI
//
//  Created by Mohab Elsayed on 27/11/2024.
//

import Foundation
import SwiftUI

enum textfieldTypes {
    case userNAme
    case Email
    case City
    case Id
    case Phone
    case Password
    case ConfirmPassword
    case messageType
    case balance
    case BankName
    case benefiterName
    case BankAccount
    case IBAN
    
    // Merchant data
    case arabicTraderName
    case englishTraderName
    case commercialNumber
    
}

// Custom TextField Component
import SwiftUI

// Custom TextField Component
struct CustomTextField: View {
    @Binding var text: String
    @State var title_label: String?
    @Binding var Validation_label: String
    @Binding var is_validation_label: Bool
    @State var is_title_label: Bool
    @State private var isEditing = false
    @State var placeholder: String?
    @State var textType : textfieldTypes
    @State var keyBoardType: UIKeyboardType = .default
    
    var body: some View {
        VStack(spacing:4) {
            VStack(spacing:8) {
                HStack {
                    CustomLabel_text(imageName: title_label ?? "", labelText: title_label ?? "")
                    Spacer()
                }
                ZStack {
                    TextField(placeholder ?? "", text: $text, onEditingChanged: { editing in
                        isEditing = editing})
                    .keyboardType(keyBoardType)
                    .padding()
                    .frame(height: 48)
                    .background(Color.CWhite)
                    .cornerRadius(8)
                    .overlay(RoundedRectangle(cornerRadius: 8).stroke((isEditing || !text.isEmpty) ? Color.MainColor : Color.TextBorderColor, lineWidth: 1))
                    .shadow(color: Color.black.opacity(0.06), radius: 6, x: 0, y: 2)
                }
                if !is_validation_label {
                    HStack{
                        Text(Validation_label.localized)
                            .font(addFont(fontType: .bold, size: 12))
                            .foregroundStyle(Color.CRed)
                        
                        Spacer()
                    }
                }
                
            }
            .onAppear() {
                switch textType {
                    
                case .userNAme:
                    title_label = "full_name".localized
                    placeholder = "enter_name".localized
                    
                case .Email:
                    title_label = "email".localized
                    placeholder = "name@gmail.com".localized
                    keyBoardType = .emailAddress
                    
                case .City:
                    title_label = "city".localized
                    placeholder = "gaddah".localized
                    
                case .Id:
                    title_label = "id_number".localized
                    placeholder = "23489756".localized
                    
                case .BankAccount:
                    title_label = "bank_account_number".localized
                    placeholder = "2389476342".localized
                    
                case .Phone:
                    title_label = "phone_number".localized
                    placeholder = "538804683".localized
                    
                case .Password:
                    title_label = "password".localized
                    placeholder = "**********".localized
                    
                case .ConfirmPassword:
                    title_label = "confirm_password".localized
                    placeholder = "**********".localized
                    
                case .messageType:
                    title_label = "Message_Title".localized
                    placeholder = "".localized
                    
                case .balance:
                    title_label = "The amount of money to be withdrawn".localized
                    placeholder = "The amount of money to be withdrawn".localized
                    
                case .BankName:
                    title_label = "Bank Name".localized
                    placeholder = "Bank Name".localized
                    
                case .benefiterName:
                    title_label = "Beneficiary's name".localized
                    placeholder = "Beneficiary's name".localized
                    
               
                    
                case .IBAN:
                    title_label = "IBAN number".localized
                    placeholder = "IBAN number".localized
                    
                case .arabicTraderName:
                    title_label = "Trade name (in Arabic)".localized
                    placeholder = "Trade name (in English)".localized
                case .englishTraderName:
                    title_label = "Trade name (in English)".localized
                    placeholder = "Trade name (in English)".localized
                case .commercialNumber:
                    title_label = "Enter the commercial registration number".localized
                    placeholder = "Enter the commercial registration number".localized
                }
            }
        }    
    }
    
    
    
}


struct SelectCustomTextField: View {
    @Binding var text: String
    @Binding var title_label: String
    @Binding var Validation_label: String
    @Binding var is_validation_label: Bool
    @Binding var is_title_label: Bool
    @Binding var isRequired :Bool
    @State var isPhoneNumber : Bool
    @State private var isEditing = false
    @State var isSelectable : Bool
    
    var placeholder: String
    
    
    var action: () -> Void // Action closure
    var body: some View {
        VStack(spacing:4) {
            VStack(spacing:8) {
                CustomLabel_text(imageName: title_label, labelText: title_label)
                ZStack {
                    TextField(placeholder, text: $text, onEditingChanged: { editing in
                        isEditing = editing})
                    .keyboardType(isPhoneNumber ? .phonePad : .default)
                    .padding()
                    
                    .frame(height: 48)
                    .background((isEditing || !text.isEmpty) ? Color.TextBorderColor.opacity(0.1) : Color.clear) // Change
                    .cornerRadius(8)
                    
                    .overlay(RoundedRectangle(cornerRadius: 8).stroke((isEditing || !text.isEmpty) ? Color.TextBorderColor : Color.gray.opacity(0.1), lineWidth: 1))
                    
                    SelectedContentButtonView(title: "") {
                        action()
                        
                    }
                }
                
                // Optional: You can add more customizations like error messages or icons here.
            }
            
        }
        
    }
}


struct textfieldExample: View {
    @State private var countryInput = ""
    @State private var country_title_label = "Country"
    @State private var country_Validation_label = "Country Is Required".localized
    @State private var isLabelHiddenCountry = true
    @State private var isRequiredCountry = true
    
    var body: some View {
        VStack {
            //  Text("Rate Us!")
            //   .font(.headline)
            
            SelectCustomTextField(text: $countryInput, title_label: $country_title_label, Validation_label: $country_Validation_label, is_validation_label: $isLabelHiddenCountry, is_title_label: $isLabelHiddenCountry, isRequired: $isRequiredCountry, isPhoneNumber: false, isSelectable: true, placeholder: "Choose Country".localized, action: {
                print("dasdasdas")
                
            })
            
            
            //  Text("Your Rating: \(userRating)")
            //     .font(.subheadline)
        }
        .padding()
    }
}

struct textfieldExampleExample_Previews: PreviewProvider {
    static var previews: some View {
        CustomTextField(text: .constant(""), Validation_label: .constant("required"), is_validation_label: .constant(false), is_title_label: true, textType: .BankAccount)
    }
}

